//Создаем объект предприятия
let itCompany1 = new Company("IT-предприятие 1");
